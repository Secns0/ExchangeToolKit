###########################################
# Written by Robert Krolikowski           #
###########################################

# ==========================
# Import Logging Module First
# ==========================
$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
Import-Module -Name (Join-Path -Path $scriptDirectory -ChildPath "Modules\Logging.psm1")

# ==========================
# Temporary Default Logging Config
# ==========================
# These default settings are used temporarily to initialize logging before full configuration is loaded.
# Default Configuration
$defaultConfig = @{
    Debug = $false
    LogDirectory = "Logs"
    LogFileName = "ScriptsSOCTool.log"
    UseTimestampedLogs = $true
    MaxLogFiles = 5
    AuditLogTimeRangeHours = 24
    AuditLogResultSize = 250
}

Initialize-Logging -ScriptDirectory $scriptDirectory -Config $defaultConfig -firstRun $true
Write-Log -Severity "INFO" -Message "Logging system initialized with default configuration."

# ==========================
# Load and Merge Configuration
# ==========================
$configFile = ".\configuration.json"

# ==========================
# Load Existing Configuration or Create New One
# ==========================
if (Test-Path -Path $configFile) {
    $config = Get-Content -Path $configFile | ConvertFrom-Json
    Write-Log -Severity "INFO" -Message "Loaded existing configuration file from $configFile."
} else {
    $config = @{}
    Write-Log -Severity "WARN" -Message "Configuration file not found. Creating a new one with default settings."
}

# ==========================
# Merge Default Configuration with Existing One
# ==========================
foreach ($key in $defaultConfig.Keys) {
    if (-not $config.PSObject.Properties.Name.Contains($key)) {
        $config | Add-Member -MemberType NoteProperty -Name $key -Value $defaultConfig[$key]
        Write-Log -Severity "INFO" -Message "Added missing configuration setting: $key with default value: $($defaultConfig[$key])."
    }
}

# ==========================
# Save Updated Configuration
# ==========================
$config | ConvertTo-Json -Depth 10 | Set-Content -Path $configFile -Force
Write-Log -Severity "INFO" -Message "Updated configuration file saved to $configFile."

# ==========================
# Reinitialize Logging with Full Configuration + Validate Configuration
# ==========================
Initialize-Logging -ScriptDirectory $scriptDirectory -Config $config -firstRun $false
$isValid = Test-Configuration -Config $config

if (-not $isValid) {
    Write-Log -Severity "ERROR" -Message "Configuration validation failed. Please correct the errors above."
    throw "Configuration validation failed."
}

Write-Log -Severity "INFO" -Message "Logging system reinitialized with full configuration."

# ==========================
# Import Remaining Modules
# ==========================
Import-Module -Name (Join-Path -Path $scriptDirectory -ChildPath "Modules\EOM.psm1")
Import-Module -Name (Join-Path -Path $scriptDirectory -ChildPath "Modules\Menu.psm1")
Import-Module -Name (Join-Path -Path $scriptDirectory -ChildPath "Modules\Tenancies.psm1")

# ==========================
# Run the Program
# ==========================
try {
    Get-Menu -ScriptDirectory $scriptDirectory -Config $config
}
catch {
    Write-Log -Severity "ERROR" -Message "Error during script execution. Error details: $_" -Redact $true
}
finally {
    Disconnect-EOMSafe
}