###########################################
# Written by Robert Krolikowski           #
###########################################

# ==========================
# Initialize Logging, set up log directory & determine log file name. Enforce log rotation
# ==========================
function Initialize-Logging {
    param (
        [Parameter(Mandatory = $true)]
        [string]$ScriptDirectory,
        
        [Parameter(Mandatory = $true)]
        [psobject]$Config,

        [Parameter(Mandatory = $true)]
        [bool]$firstRun
    )
    $script:LogDirectory = Join-Path -Path $ScriptDirectory -ChildPath $Config.LogDirectory

    # Ensure Log Directory Exists
    if (-not (Test-Path -Path $script:LogDirectory)) {
        New-Item -Path $script:LogDirectory -ItemType Directory -Force | Out-Null
    }

    # Determine Log File Name
    if ($Config.UseTimestampedLogs -eq $true) {
        $currentTimestamp = Get-Date -Format "yyyy-MM-dd_HH-mm-ss"
        $script:LogFilePath = Join-Path -Path $script:LogDirectory -ChildPath "$currentTimestamp.log"
    } else {
        $script:LogFilePath = Join-Path -Path $script:LogDirectory -ChildPath $Config.LogFileName
    }

    # Enforce Rolling Log Files
    if (!$firstRun) {
        Test-RollingLogs -LogDirectory $script:LogDirectory -MaxLogs $Config.MaxLogFiles
    }
}

# ==========================
# Rotate log files
# ==========================
function Test-RollingLogs {
    param (
        [Parameter(Mandatory = $true)]
        [string]$LogDirectory,
            
        [Parameter(Mandatory = $true)]
        [int]$MaxLogs
    )

    # Get All Log Files in the Directory
    $logFiles = Get-ChildItem -Path $LogDirectory -Filter "*.log"

    # Parse and Sort Files by Timestamp in the File Name
    $sortedFiles = $logFiles | Sort-Object -Property {
        # Extract the timestamp portion of the file name
        if ($_.BaseName -match '\d{4}-\d{2}-\d{2}_\d{2}-\d{2}-\d{2}') {
            [datetime]::ParseExact($matches[0], 'yyyy-MM-dd_HH-mm-ss', $null)
        } else {
            # Fallback to LastWriteTime if no timestamp is found
            $_.LastWriteTime
        }
    }

    # Check If the Number of Files Exceeds the Limit
    if ($sortedFiles.Count -gt $MaxLogs) {
        # Calculate the Number of Files to Remove
        $filesToRemove = $sortedFiles.Count - $MaxLogs

        # Remove Oldest Files
        $sortedFiles | Select-Object -First $filesToRemove | ForEach-Object {
            Write-Log -Severity "INFO" -Message "Deleting old log file: $($_.FullName)"
            Remove-Item -Path $_.FullName -Force
        }
    }
}

# ==========================
# Configuration Validation Function
# ==========================
function Test-Configuration {
    param (
        [Parameter(Mandatory = $true)]
        [psobject]$Config
    )

    # Assume everything is valid until proven otherwise
    $isValid = $true

    # Debug (bool)
    if ($Config.Debug -isnot [bool]) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'Debug' must be a Boolean value (true/false)."
        $isValid = $false
    }

    # LogDirectory (string, max length = 20, min length = 2)
    if ($Config.LogDirectory -isnot [string]) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'LogDirectory' must be a string."
        $isValid = $false
    }
    elseif ($Config.LogDirectory.Length -lt 4) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'LogDirectory' must be at least 2 characters."
        $isValid = $false
    }
    elseif ($Config.LogDirectory.Length -gt 20) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'LogDirectory' exceeds the maximum of 20 characters."
        $isValid = $false
    }

    # LogFileName (string, max length = 40, min length = 4)
    if ($Config.LogFileName -isnot [string]) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'LogFileName' must be a string."
        $isValid = $false
    }
    elseif ($Config.LogFileName.Length -lt 4) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'LogFileName' must be at least 4 characters."
        $isValid = $false
    }
    elseif ($Config.LogFileName.Length -gt 40) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'LogFileName' exceeds the maximum of 40 characters."
        $isValid = $false
    }

    # UseTimestampedLogs (bool)
    if ($Config.UseTimestampedLogs -isnot [bool]) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'UseTimestampedLogs' must be a Boolean value."
        $isValid = $false
    }

    # MaxLogFiles (int, 1 <= value <= 20)
    if ($Config.MaxLogFiles -isnot [int]) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'MaxLogFiles' must be an integer."
        $isValid = $false
    }
    elseif ($Config.MaxLogFiles -lt 1) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'MaxLogFiles' must be at least 1."
        $isValid = $false
    }
    elseif ($Config.MaxLogFiles -gt 20) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'MaxLogFiles' must not exceed 20."
        $isValid = $false
    }

    # AuditLogTimeRangeHours (int, 1 <= value <= 720)
    if ($Config.AuditLogTimeRangeHours -isnot [int]) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'AuditLogTimeRangeHours' must be an integer."
        $isValid = $false
    }
    elseif ($Config.AuditLogTimeRangeHours -lt 1) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'AuditLogTimeRangeHours' must be at least 1."
        $isValid = $false
    }
    elseif ($Config.AuditLogTimeRangeHours -gt 720) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'AuditLogTimeRangeHours' must not exceed 720."
        $isValid = $false
    }

    # AuditLogResultSize (int, 50 <= value <= 750)
    if ($Config.AuditLogResultSize -isnot [int]) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'AuditLogResultSize' must be an integer."
        $isValid = $false
    }
    elseif ($Config.AuditLogResultSize -lt 50) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'AuditLogResultSize' must be at least 50."
        $isValid = $false
    }
    elseif ($Config.AuditLogResultSize -gt 750) {
        Write-Log -Severity "ERROR" -Message "Configuration Error: 'AuditLogResultSize' must not exceed 750."
        $isValid = $false
    }

    return $isValid
}

# ==========================
# Write a log entry to file, with optional redaction
# ==========================
function Write-Log {
    param (
        [Parameter(Mandatory = $true)]
        [string]$Severity,
            
        [Parameter(Mandatory = $true)]
        [string]$Message,

        [Parameter(Mandatory = $false)]
        [bool]$Redact = $false
    )

    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $currentUser = $env:USERNAME

    $callStack = Get-PSCallStack
    if ($callStack.Count -gt 1) {
        $caller = $callStack[1]
        $functionAndLine = "$($caller.FunctionName):$($caller.ScriptLineNumber)"
    }
    else {
        $functionAndLine = "Main"
    }

    if ($Redact) {
        # Redact sensitive information
        $Message = $Message -replace '\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b', '[REDACTED_EMAIL]'
        $Message = $Message -replace '\b\d{1,3}(\.\d{1,3}){3}\b', '[REDACTED_IP]'
        $Message = $Message -replace '\b[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+\b', '[REDACTED_DOMAIN]'
        $Message = $Message -replace '[a-zA-Z]:\\(?:[^\\/:*?"<>|\r\n]+\\)*[^\\/:*?"<>|\r\n]*|\b\\\\[^\\/:*?"<>|\r\n]+\b', '[REDACTED_FILEPATH]'
    }

    $logEntry = "$timestamp | $currentUser | $Severity | $functionAndLine | $Message"

    Write-Output $logEntry | Out-File -FilePath $script:LogFilePath -Append

    if ($Severity -eq "ERROR") {
        Write-Host $logEntry -ForegroundColor Red
    } elseif ($Config.Debug) {
        Write-Host $logEntry -ForegroundColor Yellow
    }
}

Export-ModuleMember -Function Initialize-Logging, Write-Log, Test-RollingLogs, Test-Configuration