###########################################
# Written by Robert Krolikowski           #
###########################################
$TenantLookup = @(
    [PSCustomObject]@{
        Domain  = 'ageukcountydurham.org.uk'
        Tenancy = 'Age UK'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'alliancehomes.org.uk'
        Tenancy = 'Alliance Homes'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'Arhagsocialhousing.onmicrosoft.com'
        Tenancy = 'ARHAG Housing Association'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'aaf.edu.au'
        Tenancy = 'Australian Access Federation'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'bfinance.com'
        Tenancy = 'BFinance'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'bw-medical.co.uk'
        Tenancy = 'BW Medical'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'caudit.edu.au'
        Tenancy = 'Caudit'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'cscb.onmicrosoft.com'
        Tenancy = 'Coin Street'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'crosskeyshomes1.onmicrosoft.com'
        Tenancy = 'Cross Keys Homes'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'cundall.com'
        Tenancy = 'Cundall'
        Note    = 'PIM Required to run script'
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'ext.customssupport.com'
        Tenancy = 'Customs Support'
        Note    = 'PIM Required to get Mailboxes, please make sure PIM is active on the account. Else mailboxes will not be found'
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'EastLothianHousing.onmicrosoft.com'
        Tenancy = 'East Lothian Housing Association'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'eildon.org.uk'
        Tenancy = 'Eildon Housing'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'enva.com'
        Tenancy = 'Enva Group'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'eventhorizonent.onmicrosoft.com'
        Tenancy = 'Event Horizon Entertainment'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'eventhorizonent.onmicrosoft.com'
        Tenancy = 'Event Horizon Entertainment'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'fidraenergy.onmicrosoft.com'
        Tenancy = 'Fidra Energy'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'FTTechnologies.onmicrosoft.com'
        Tenancy = 'FT Technologies'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'gatewayhousing.onmicrosoft.com'
        Tenancy = 'Gateway Housing'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'glennhowells.onmicrosoft.com'
        Tenancy = 'Glenn Howells Architects'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'guindulgentfoods.onmicrosoft.com'
        Tenancy = 'GU Puds'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'hawkinsbrown.com'
        Tenancy = 'Hawkins Brown'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'heatherwick.com'
        Tenancy = 'Heatherwick Studio'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'HenryColbeck.onmicrosoft.com'
        Tenancy = 'Henry Colbeck'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'ISIO.com'
        Tenancy = 'Isio'
        Note    = 'PIM Required to run script. Ensure the following roles are active on PIM: Exchange Administrator and Security Administrator'
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'thepensionsplatform.co.uk'
        Tenancy = 'Isio (ITRB Tenancy)'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'jehallcouk.onmicrosoft.com'
        Tenancy = 'J & E Hall'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'james-fisher.co.uk'
        Tenancy = 'James Fisher'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'jamesjones.co.uk'
        Tenancy = 'James Jones & Sons'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'jesticowhiles.onmicrosoft.com'
        Tenancy = 'Jestico + Whiles'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'jrf.org.uk'
        Tenancy = 'Joseph Rowntree Foundation'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'jtp365.onmicrosoft.com'
        Tenancy = 'JTP LLP'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'housingict.co.uk'
        Tenancy = 'Karbon Homes'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'kineticprivateinvestments.onmicrosoft.com'
        Tenancy = 'Kinetic Private Investments'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'levittbernstein.onmicrosoft.com'
        Tenancy = 'Levitt Bernstein Architects'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'quornfoods.com'
        Tenancy = 'Marlow/Quorn Foods'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'mayborngroup.com'
        Tenancy = 'Mayborn'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'meadowfoods.co.uk'
        Tenancy = 'Meadow Foods'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'moneypennywealth.onmicrosoft.com'
        Tenancy = 'Moneypenny Wealth Management'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'mpl.co.uk'
        Tenancy = 'MPL Communications Limited'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'nataraglobal.onmicrosoft.com'
        Tenancy = 'Natara Global'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'natcen.ac.uk'
        Tenancy = 'Natcen Social Research'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'navigatorterminals.onmicrosoft.com'
        Tenancy = 'Navigator Terminals'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'nwha.org.uk'
        Tenancy = 'North Wales Housing Association'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'ruok.org.au'
        Tenancy = 'R U OK?'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'riverclydehomes.org.uk'
        Tenancy = 'River Clyde Homes'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'scottishautism.org'
        Tenancy = 'Scottish Autism'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'scottishfuturestrust.org.uk'
        Tenancy = 'Scottish Futures Trust Limited'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'mineracaoserraverde.onmicrosoft.com'
        Tenancy = 'Serra Verde (SVPM Tenancy)'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'simpsonsmalt.co.uk'
        Tenancy = 'Simpsons Malt (Ltd)'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'sixmiles.onmicrosoft.com'
        Tenancy = 'Six Miles Across London'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'smd.co.uk'
        Tenancy = 'Soil Machine Dynamics'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'treat-nmd.com'
        Tenancy = 'Treat-NMD'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'westhq.com.au'
        Tenancy = 'West HQ'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'westmorlandfamily.onmicrosoft.com'
        Tenancy = 'Westmorland LTD'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'wilkinsoneyre.com'
        Tenancy = 'Wilkinson Eyre Architects'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'armstrongceilingsolutions.onmicrosoft.com'
        Tenancy = 'Zentia/Armstrong Ceilings'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'amphora.net'
        Tenancy = 'Amphora'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'cardiffmet.ac.uk'
        Tenancy = 'Cardiff Metropolitan University'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'durhamuniversity.onmicrosoft.com'
        Tenancy = 'Durham University'
        Note    = 'Will need PIM to reset passwords + revoke sessions'
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'evergreengarden.com'
        Tenancy = 'Evergreen Garden'
        Note    = 'Will need JIT Access. Please see: https://evergreen.support.waterstons.com/a/solutions/articles/50000181915?language=en'
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'footasylum.com'
        Tenancy = 'Footasylum'
        Note    = 'Will need PAM & PIM Roles'
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'leedsbeckett.ac.uk'
        Tenancy = 'Leeds Beckett University'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'waterstons.com'
        Tenancy = 'Waterstons'
        Note    = $null
        TenancyIdentifider = $null
    },
    [PSCustomObject]@{
        Domain  = 'winchdesign.com'
        Tenancy = 'Winch Design'
        Note    = 'Will need PIM Roles'
        TenancyIdentifider = $null
    }
    [PSCustomObject]@{
        Domain  = 'thebodyshop.com'
        Tenancy = 'The Body Shop (TBS)'
        Note    = $null
        TenancyIdentifider = $null
    }
    [PSCustomObject]@{
        Domain  = 'propersnacks.com'
        Tenancy = 'Proper Snacks'
        Note    = 'Will need PIM roles'
        TenancyIdentifider = $null
    }
)

Export-ModuleMember -Variable TenantLookup