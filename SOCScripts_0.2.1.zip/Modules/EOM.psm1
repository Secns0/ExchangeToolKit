###########################################
# Written by Robert Krolikowski           #
###########################################

# ==========================
# Stores mailbox rules list and last queried inbox
# ==========================
$script:MailboxRulesList = @()
$script:LastMailboxQueried = $null

# ==========================
# Returns the mailbox type
# ==========================
function Get-ValidatedMailboxType {
    [CmdletBinding()]
    param(
      [Parameter(Mandatory)]
      [string]$Mailbox,
      [Parameter(Mandatory)]
      [psobject]$Config
    )

    try {
        $mbx = Get-Mailbox -Identity $Mailbox -ErrorAction Stop
        if ($Config.Debug) {
            Write-Host "==================================================" -ForegroundColor Cyan
            Write-Host "DEBUG: Mailbox Object Full Result: $($mbx | Format-List | Out-String)" -ForegroundColor White
            Write-Host "DEBUG: RecipientTypeDetails: $($mbx.RecipientTypeDetails)" -ForegroundColor White
            Write-Host "==================================================" -ForegroundColor Cyan
        }
    }
    catch {
        Write-Log -Severity "INFO" -Message "The mailbox '$Mailbox' was not found. Please verify the email address." -Redact $true
        Write-Host "==================================================" -ForegroundColor Yellow
        Write-Host "The mailbox '$Mailbox' was not found. Please verify the email address." -ForegroundColor White
        Write-Host "==================================================" -ForegroundColor Yellow
        return $null
    }

    switch ($mbx.RecipientTypeDetails) {
        "SharedMailbox" {
            Write-Log -Severity "INFO" -Message "WARNING: The mailbox '$Mailbox' is a Shared Mailbox. Proceeding with limited support." -Redact $true
            Write-Host "==================================================" -ForegroundColor Yellow
            Write-Host "WARNING: The mailbox '$Mailbox' is a SharedMailbox. An attempt will be made to continue." -ForegroundColor Yellow
            Write-Host "==================================================" -ForegroundColor Yellow
            return $mbx
        }
        "UserMailbox" {
            return $mbx
        }
        default {
            Write-Log -Severity "INFO" -Message "The mailbox '$Mailbox' is a $($mbx.RecipientTypeDetails) and cannot be processed." -Redact $true
            Write-Host "==================================================" -ForegroundColor Yellow
            Write-Host "The mailbox '$Mailbox' is a $($mbx.RecipientTypeDetails) and cannot be processed." -ForegroundColor Red
            Write-Host "==================================================" -ForegroundColor Yellow
            return $null
        }
    }
}

# ==========================
# Check if Exchange Online Management is installed
# ==========================
function Test-EOMModule {
    param(
        [Version]$MinimumVersion = [Version]'3.9.0'
    )

    $module = Get-Module -ListAvailable -Name ExchangeOnlineManagement |
              Sort-Object Version -Descending |
              Select-Object -First 1

    if (-not $module) {
        Write-Log -Severity "INFO" -Message "EOM module not detected."
        return [pscustomobject]@{
            Installed       = $false
            MeetsMinimum    = $false
            InstalledVersion= $null
            MinimumVersion  = $MinimumVersion
            Module          = $null
        }
    }

    $installedVersion = [Version]$module.Version
    $meets = ($installedVersion -ge $MinimumVersion)

    Write-Log -Severity "INFO" -Message "EOM module detected. Version: $installedVersion"

    return [pscustomobject]@{
        Installed        = $true
        MeetsMinimum     = $meets
        InstalledVersion = $installedVersion
        MinimumVersion   = $MinimumVersion
        Module           = $module
    }
}

# ==========================
# Ensure Exchange Online Management meets minimum specified version
# ==========================
function Test-EOMMinimum {
    param(
        [Version]$MinimumVersion = [Version]'3.9.0',
        [switch]$AutoUpdate      # optional: auto-update without prompting
    )

    $res = Test-EOMModule -MinimumVersion $MinimumVersion

    if ($res.MeetsMinimum) {
        return $true
    }

    if (-not $res.Installed) {
        Write-Host ("ExchangeOnlineManagement is not installed. Minimum required: {0}" -f $MinimumVersion) -ForegroundColor Yellow
    } else {
        Write-Host ("ExchangeOnlineManagement {0} detected, but {1} or higher is required." -f $res.InstalledVersion, $MinimumVersion) -ForegroundColor Yellow
    }

    if (-not $AutoUpdate) {
        $ans = Read-Host "Would you like to install/update ExchangeOnlineManagement for the current user now? (Y/N)"
        if (-not $ans.StartsWith('Y','CurrentCultureIgnoreCase')) {
            Write-Host "Cannot continue without ExchangeOnlineManagement $MinimumVersion+. Exiting." -ForegroundColor Red
            return $false
        }
    } else {
        Write-Host "AutoUpdate enabled. Updating ExchangeOnlineManagement..." -ForegroundColor Yellow
    }

    try {
        # Install or update for CurrentUser
        if (-not $res.Installed) {
            Install-Module ExchangeOnlineManagement -Scope CurrentUser -Force -AllowClobber
        } else {
            Update-Module ExchangeOnlineManagement -Scope CurrentUser -Force
        }

        # Reload latest version in-session
        Remove-Module ExchangeOnlineManagement -ErrorAction SilentlyContinue
        Import-Module ExchangeOnlineManagement -ErrorAction Stop

        $newVer = (Get-Module ExchangeOnlineManagement -ListAvailable | Sort-Object Version -Descending | Select-Object -First 1).Version
        if ([Version]$newVer -lt $MinimumVersion) {
            Write-Host ("Update completed but version is still {0}. Please update manually (try elevated PowerShell)." -f $newVer) -ForegroundColor Red
            return $false
        }

        Write-Host ("ExchangeOnlineManagement updated/installed successfully. Version: {0}" -f $newVer) -ForegroundColor Green
        return $true
    } catch {
        Write-Host ("Failed to install/update ExchangeOnlineManagement: {0}" -f $_) -ForegroundColor Red
        return $false
    }
}

# ==========================
# Install the Exchange Online Management Module
# ==========================
function Install-EOMModule {
    Write-Log -Severity "INFO" -Message "Attempting to install EOM module..."
    try {
        Install-Module -Name ExchangeOnlineManagement -Force -Scope CurrentUser -AllowClobber
        Write-Log -Severity "SUCCESS" -Message "EOM module installed successfully."
    } catch {
        Write-Log -Severity "ERROR" -Message "Failed to install EOM module: $_"
        throw $_
    }
}

# ==========================
# Connect to Exchange Online Management with GDAP Support
# ==========================
function Connect-EOM {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Username,

        [Parameter(Mandatory=$false)]
        [string]$Organization
    )
    Write-Log -Severity "INFO" -Message "Attempting to connect to EOM as $Username..." -Redact $true
    try {
        if ($Organization) {
            Connect-ExchangeOnline -UserPrincipalName $Username -Organization $Organization
            Write-Log -Severity "SUCCESS" -Message "Successfully connected to EOM as $Username to organization $Organization" -Redact $true
        }
        else {
            Connect-ExchangeOnline -UserPrincipalName $Username
            Write-Log -Severity "SUCCESS" -Message "Successfully connected to EOM as $Username." -Redact $true
        }
    } catch {
        Write-Log -Severity "ERROR" -Message "Failed to connect to EOM: $_"
        throw $_
    }
}

# ==========================
# Connect to Security & Compliance with GDAP Support
# ==========================
function Connect-IPPS {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Username,

        [Parameter(Mandatory=$false)]
        [string]$Organization
    )
    Write-Log -Severity "INFO" -Message "Attempting to connect to Security & Compliance as $Username..." -Redact $true
    try {
        if ($Organization) {
            Connect-IPPSSession -UserPrincipalName $Username -Organization $Organization -EnableSearchOnlySession -ErrorAction Stop
            Write-Log -Severity "SUCCESS" -Message "Successfully connected to Security & Compliance as $Username to organization $Organization" -Redact $true
        }
        else {
            Connect-IPPSSession -UserPrincipalName $Username -EnableSearchOnlySession -ErrorAction Stop
            Write-Log -Severity "SUCCESS" -Message "Successfully connected to Security & Compliance as $Username." -Redact $true
        }
    } catch {
        Write-Log -Severity "ERROR" -Message "Failed to connect to Security & Compliance: $_"
        throw $_
    }
}

# ==========================
# Disconnect from Exchange Online Management
# ==========================
function Disconnect-EOMSafe {
    Write-Log -Severity "INFO" -Message "Attempting to disconnect from EOM..."
    try {
        Disconnect-ExchangeOnline -Confirm:$false
        Write-Log -Severity "SUCCESS" -Message "Disconnected from EOM."
    } catch {
        Write-Log -Severity "ERROR" -Message "Failed to disconnect from EOM: $_"
    }
}

# ==========================
# Retrieve and display Inbox Rules for a specific mailbox
# ==========================
function Get-MailboxRules {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$Mailbox,

        [Parameter(Mandatory = $true)]
        [psobject]$Config,

        [Parameter(Mandatory = $false)]
        [psobject]$SkipOutput,

        [Parameter(Mandatory = $false)]
        [psobject]$RuleName = $null
    )

    # Mailbox type check
    $mbx = Get-ValidatedMailboxType -Mailbox $Mailbox -Config $Config

    if (-not $mbx) { 
        return 
    }

    Write-Log -Severity "INFO" -Message "Attempting to retrieve inbox rules for mailbox '$Mailbox'." -Redact $true

    try {        
        if ([string]::IsNullOrWhiteSpace($RuleName)) {
            $rules = Get-InboxRule -Mailbox $Mailbox -IncludeHidden -ErrorAction Stop
        } else {
            $rules = Get-InboxRule -Mailbox $Mailbox -Identity $RuleName -IncludeHidden -ErrorAction Stop
        }

        $script:MailboxRulesList = @()
        $i = 1
        foreach ($rule in $rules) {
            if ($Config.Debug) {
                Write-Host "==================================================" -ForegroundColor Cyan
                Write-Host "DEBUG: JSON Rule Value: $(ConvertTo-Json $rule -Depth 10)" -ForegroundColor White
                Write-Host "==================================================" -ForegroundColor Cyan
            }

            $parts = $rule.Identity -split '\\'
            $ruleId = $parts[1]

            $script:MailboxRulesList += [PSCustomObject]@{
                Number                = $i
                Identity              = $ruleId
                Name                  = $rule.Name
                Enabled               = $rule.Enabled
                Priority              = $rule.Priority
                Description           = $rule.Description
                IsValid               = $rule.IsValid
                ForwardTo             = if ($rule.ForwardTo) { $rule.ForwardTo -join '; ' } else { '' }
                ForwardAsAttachmentTo = if ($rule.ForwardAsAttachmentTo) { $rule.ForwardAsAttachmentTo -join '; ' } else { '' }
                RedirectTo            = if ($rule.RedirectTo) { $rule.RedirectTo -join '; ' } else { '' }
                MoveToFolder          = $rule.MoveToFolder
            }
            if(!$SkipOutput) {
                Write-Host ""
                Write-Host "====================================" -ForegroundColor Cyan
                Write-Host "Rule Identity: $ruleId"
                Write-Host "Rule Number:  $i"
                Write-Host "Rule Name:    $($rule.Name)"
                Write-Host "Valid:        $($rule.IsValid)"
                Write-Host "Enabled:      $($rule.Enabled)"
                Write-Host "Priority:     $($rule.Priority)"
                Write-Host "Description:  $($rule.Description)"

                if ($rule.ForwardTo) {
                    Write-Host "ForwardTo:    $($rule.ForwardTo -join '; ')" -ForegroundColor Yellow
                }
                if ($rule.ForwardAsAttachmentTo) {
                    Write-Host "ForwardAsAttachmentTo: $($rule.ForwardAsAttachmentTo -join '; ')" -ForegroundColor Yellow
                }
                if ($rule.RedirectTo) {
                    Write-Host "RedirectTo:   $($rule.RedirectTo -join '; ')" -ForegroundColor Yellow
                }
                if ($rule.MoveToFolder) {
                    Write-Host "MoveToFolder: $($rule.MoveToFolder)" -ForegroundColor Yellow
                }
    
                Write-Host "====================================" -ForegroundColor Cyan
            }

            $i++ # Increment rule number after displaying the current rule number (Which starts at 1)
        }

        if ($script:MailboxRulesList.Count -gt 0) {
            Write-Log -Severity "INFO" -Message "Retrieved $($script:MailboxRulesList.Count) rules for mailbox '$Mailbox'" -Redact $true
            $script:LastMailboxQueried = $Mailbox
            if ($Config.Debug) {
                $script:MailboxRulesList | Format-Table Number, Name, Enabled, Priority -AutoSize
            }
        }
        else {
            Write-Host "==================================================" -ForegroundColor Yellow
            Write-Host "No rules found for mailbox '$Mailbox'." -ForegroundColor White
            Write-Host "==================================================" -ForegroundColor Yellow
            Write-Log -Severity "INFO" -Message "No rules found for mailbox '$Mailbox'." -Redact $true
        }
    }
    catch {
        Write-Log -Severity "ERROR" -Message "Failed to retrieve rules for mailbox '$Mailbox': $_" -Redact $true
        throw $_
    }
}

# ==========================
# Retrieve and display auto-reply settings for a mailbox
# ==========================
function Get-MailboxAutoReply {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Mailbox,

        [Parameter(Mandatory = $true)]
        [psobject]$Config,

        [Parameter(Mandatory = $false)]
        [psobject]$SkipOutput
    )

    Write-Log -Severity "INFO" -Message "Attempting to retrieve auto reply configuration for mailbox '$Mailbox'." -Redact $true

    # Mailbox type check
    $mbx = Get-ValidatedMailboxType -Mailbox $Mailbox -Config $Config
    
    if (-not $mbx) { 
        return 
    }

    try {
        $autoReplyConfig = Get-MailboxAutoReplyConfiguration -Identity $Mailbox -ErrorAction Stop

        if (-not $SkipOutput) {
            Write-Host "====================================" -ForegroundColor Cyan
            Write-Host "Mailbox:           $Mailbox"
            Write-Host "AutoReply State:   $($autoReplyConfig.AutoReplyState)"
            Write-Host "Start Time:        $($autoReplyConfig.StartTime)"
            Write-Host "End Time:          $($autoReplyConfig.EndTime)"
            Write-Host "Internal Message:  $($autoReplyConfig.InternalMessage)"
            Write-Host "External Message:  $($autoReplyConfig.ExternalMessage)"
            Write-Host "External Audience: $($autoReplyConfig.ExternalAudience)"
            Write-Host "====================================" -ForegroundColor Cyan
        }

        Write-Log -Severity "INFO" -Message "Retrieved auto reply configuration for mailbox '$Mailbox'" -Redact $true

        if ($Config.Debug) {
            Write-Debug ("Auto Reply Config JSON: " + (ConvertTo-Json $autoReplyConfig -Depth 5))
        }

        return $autoReplyConfig
    }
    catch {
        Write-Log -Severity "ERROR" -Message "Failed to retrieve auto reply configuration for mailbox '$Mailbox': $_" -Redact $true
        throw $_
    }
}

# ==========================
# Search audit log for specific inbox rule operations
# ==========================
function Get-InboxRuleHistory {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Mailbox,

        [Parameter(Mandatory = $false)]
        [string]$RuleName,

        [Parameter(Mandatory = $false)]
        [datetime]$StartDate = (Get-Date).AddHours(-24),

        [Parameter(Mandatory = $false)]
        [datetime]$EndDate = (Get-Date),

        [Parameter(Mandatory = $true)]
        [psobject]$Config,

        [Parameter(Mandatory = $false)]
        [bool]$SkipRulename,

        [Parameter(Mandatory = $false)]
        [bool]$SkipOutput = $false
    )

    # Mailbox type check
    $mbx = Get-ValidatedMailboxType -Mailbox $Mailbox -Config $Config

    if (-not $mbx) { 
        return 
    }

    Write-Log -Severity "INFO" -Message "Retrieving audit log events for inbox rules for mailbox '$Mailbox' from $StartDate to $EndDate." -Redact $true

    try {
        $operations = "New-InboxRule", "Set-InboxRule", "UpdateInboxRules"

        $auditResults = Search-UnifiedAuditLog `
            -StartDate   $StartDate `
            -EndDate     $EndDate `
            -UserIds     $Mailbox `
            -Operations  $operations `
            -ResultSize  $Config.AuditLogResultSize `
            -ErrorAction Stop

        if ($auditResults) {

            if ($Config.Debug) {
                Write-Host "==================================================" -ForegroundColor Cyan
                Write-Host "DEBUG: Audit Results:" -ForegroundColor White
                $auditResults | Out-String | Write-Host
                Write-Host "==================================================" -ForegroundColor Cyan
            }

            $events = $auditResults | ForEach-Object {

                $auditData = $_.AuditData | ConvertFrom-Json

                $props = @()
                if ($auditData.Parameters) {
                    $props += $auditData.Parameters
                }
                if ($auditData.OperationProperties) {
                    $props += $auditData.OperationProperties
                }

                $ruleNameParam = $props | Where-Object { $_.Name -eq 'RuleName' }
                $realRuleName  = $ruleNameParam.Value

                # Split the IP & Port and craft the required links

                $ipPortParts = $auditData.ClientIP -split ':'
                $clientIP    = $ipPortParts[0]
                $clientPort  = if ($ipPortParts.Count -gt 1) { $ipPortParts[1] } else { $null }

                $VirusTotalUrl = "https://www.virustotal.com/gui/ip-address/$clientIP"
                $LiveIpMapUrl  = "https://www.liveipmap.com/"
                $AbuseIPDBUrl  = "https://www.abuseipdb.com/check/$clientIP"

                $baseProps = @{
                    Timestamp     = $_.CreationDate
                    Operation     = $auditData.Operation
                    Initiator     = $auditData.UserId       
                    RuleName      = $realRuleName           
                    ClientIP      = $clientIP
                    ClientPort    = $clientPort
                    VirusTotalUrl = $VirusTotalUrl
                    LiveIpMapUrl  = $LiveIpMapUrl
                    AbuseIPDBUrl  = $AbuseIPDBUrl
                    OrgName       = $auditData.OrganizationName
                    Details       = ($auditData | ConvertTo-Json -Depth 5)
                }

                # Create a hashtable for dynamic parameter properties.
                $paramProps = @{}
                foreach ($p in $props) {
                    $paramProps["Param_$($p.Name)"] = $p.Value
                }
                
                # Merge the two 
                $allProps = $baseProps + $paramProps

                [PSCustomObject]$allProps
            }

            if ($RuleName) {
                $events = $events | Where-Object { $_.RuleName -eq $RuleName }
            } else {
                if(!$SkipRulename) {
                    Write-Log -Severity "INFO" -Message "Audit logs have been found. However, no events found for '$Mailbox' using the specified Rule Name" -Redact $true
                    Write-Host "==================================================" -ForegroundColor Yellow
                    Write-Host "Audit logs have been found. However, no events found for '$Mailbox'$(if($RuleName){ " and rule '$RuleName'" })" -ForegroundColor Yellow
                    Write-Host "Note: This may be due to the timeframe currently used or the audit log hasn't been updated yet" -ForegroundColor Yellow
                    Write-Host "Current timeframe used: $StartDate to $EndDate."
                    Write-Host "==================================================" -ForegroundColor Yellow
                }
            }

            if ($events) {
                if (!$SkipOutput) {
                    Write-Host "Audit log events for mailbox '$Mailbox'$(if($RuleName){ " and rule '$RuleName'" }):" -ForegroundColor Green
                }

                $sortedEvents = $events | Sort-Object -Property Timestamp

                # Structuring Properties for List
                $baseProps = 'Timestamp','Operation','Initiator','RuleName','ClientIP','ClientPort','VirusTotalUrl','LiveIpMapUrl','AbuseIPDBUrl','OrgName'
                
                $dynamicProps = $sortedEvents `
                    | ForEach-Object { $_.PSObject.Properties.Name } `
                    | Where-Object { $_ -like 'Param_*' } `
                    | Sort-Object -Unique

                $selectedProperties = $baseProps + $dynamicProps

                if ($Config.Debug) {
                    if (!$SkipOutput) {
                        $sortedEvents | Select-Object -Property $selectedProperties
                                        @{Name='Details'; Expression={ $_.Details }} |
                            Format-List
                    } else {
                        return $sortedEvents
                    }
                }
                else {
                    if (!$SkipOutput) {
                        $sortedEvents | Select-Object -Property $selectedProperties | Format-List
                        Out-Host
                    } else {
                        return $sortedEvents
                    }
                }
            }
        }
        else {
            Write-Log -Severity "INFO" -Message "No audit log events found for mailbox '$Mailbox' in the specified date range." -Redact $true
            Write-Host "==================================================" -ForegroundColor Yellow
            Write-Host "No audit log events found for mailbox '$Mailbox' $(if($RuleName){ " and rule '$RuleName'" }) in the specified date range." -ForegroundColor Yellow
            Write-Host "==================================================" -ForegroundColor Yellow
        }
    }
    catch {
        Write-Log -Severity "ERROR" -Message "Failed to retrieve audit log events for mailbox '$Mailbox': $_" -Redact $true
        throw $_
    }
}

# ==========================
# Remove a specific inbox rule by it's identity ID (Not Name)
# ==========================
function Remove-InboxRuleByID {
    [CmdletBinding(SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Mailbox,

        [Parameter(Mandatory = $true)]
        [string]$RuleID,

        [Parameter(Mandatory = $true)]
        [psobject]$Config
    )

    if ($PSCmdlet.ShouldProcess("Mailbox: $Mailbox, Rule: $RuleID", "Remove the specified inbox rule")) {
        try {
            Remove-InboxRule -Mailbox $Mailbox -Identity $RuleID -Confirm:$false -ErrorAction Stop
            Write-Host "Successfully removed inbox rule '$RuleID' for mailbox '$Mailbox'." -ForegroundColor Green
            Write-Log -Severity "INFO" -Message "Successfully removed inbox rule for mailbox '$Mailbox'." -Redact $true
        }
        catch {
            Write-Log -Severity "ERROR" -Message "Failed to remove inbox rule for mailbox '$Mailbox'. Error details: $_" -Redact $true
        }
    }
}

# PURGING FUNCTIONS START

# ==========================
# Build safe KQL fragments
# ==========================
function New-SafeKqlString {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Text
    )
    # Basic escape for double quotes in KQL
    return $Text.Replace('"', '\"')
}

# ==========================
# Construct Purview KQL query
# ==========================
function New-PurviewKqlQuery {
    [CmdletBinding()]
    param(
        [Parameter()]
        [string]$_Sender,

        [Parameter()]
        [string]$Subject,

        [Parameter()]
        [string[]]$Recipients,

        [Parameter()]
        [Nullable[datetime]]$StartDate,

        [Parameter()]
        [Nullable[datetime]]$EndDate
    )

    $clauses = @()

    if (-not [string]::IsNullOrWhiteSpace($_Sender)) {
        $safeSender = New-SafeKqlString -Text $_Sender
        $clauses += "sender:$safeSender"
    }

    # Subject (optional)
    if ($Subject) {
        $safeSubject = New-SafeKqlString -Text $Subject
        $clauses += "subject:`"$safeSubject`""
    }

    # Recipients block (To/CC/BCC; optional)
    if ($Recipients -and $Recipients.Count -gt 0) {
        $recipientClauses = @()
        foreach ($r in $Recipients) {
            $safeR = New-SafeKqlString -Text $r
            $recipientClauses += "(recipients:$safeR OR to:$safeR OR cc:$safeR OR bcc:$safeR)"
        }
        if ($recipientClauses.Count -gt 0) {
            # Wrap all recipient clauses in a single () group
            $clauses += "(" + ($recipientClauses -join " OR ") + ")"
        }
    }

    # Date range on Received (optional)
    if ($StartDate -and $EndDate) {
        $from = (Get-Date $StartDate).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        $to   = (Get-Date $EndDate).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        $clauses += "received>=$from AND received<=$to"
    }
    elseif ($StartDate) {
        $from = (Get-Date $StartDate).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        $clauses += "received>=$from"
    }
    elseif ($EndDate) {
        $to = (Get-Date $EndDate).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
        $clauses += "received<=$to"
    }

    if ($clauses.Count -eq 0) {
        throw "KQL query would be empty. Provide at least one filter (Sender, Subject, Recipients, or Date range)."
    }

    $kql = $clauses -join " AND "
    return $kql
}

# ==========================
# Create and start Purview compliance search
# ==========================
function Start-PurviewSearch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$SearchName,

        [Parameter(Mandatory)]
        [string]$Kql,

        [Parameter()]
        [string[]]$ExchangeLocations = @("All")
    )

    # Ensure an existing search with the same name is handled
    $existing = Get-ComplianceSearch -Identity $SearchName -ErrorAction SilentlyContinue
    if ($existing) {
        Write-Host "Compliance search '$SearchName' already exists. Reusing." -ForegroundColor Yellow
        Set-ComplianceSearch -Identity $SearchName -ExchangeLocation $ExchangeLocations -ContentMatchQuery $Kql -ErrorAction Stop
    } else {
        New-ComplianceSearch -Name $SearchName -ExchangeLocation $ExchangeLocations -ContentMatchQuery $Kql -ErrorAction Stop | Out-Null
    }

    Start-ComplianceSearch -Identity $SearchName -ErrorAction Stop | Out-Null
    Write-Host "Search '$SearchName' started." -ForegroundColor Green
}

# ==========================
# Poll Purview search until terminal state
# ==========================
function Wait-PurviewSearch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$SearchName,

        [Parameter()]
        [int]$TimeoutSeconds = 1200, # 20 Minute timeout

        [Parameter()]
        [int]$PollSeconds = 5
    )

    $sw = [Diagnostics.Stopwatch]::StartNew()
    do {
        Start-Sleep -Seconds $PollSeconds
        $search = Get-ComplianceSearch -Identity $SearchName -ErrorAction Stop
        Write-Host "Waiting... Status=$($search.Status), LastRunTime=$($search.LastRunTime), Items=$($search.Items)" -ForegroundColor DarkGray
        $terminal = $search.Status -in 'Completed','PartiallySucceeded','Failed','Stopped'
    } while (-not $terminal -and $sw.Elapsed.TotalSeconds -lt $TimeoutSeconds)
    $sw.Stop()

    # Return final search state
    return (Get-ComplianceSearch -Identity $SearchName -ErrorAction Stop)
}

# ==========================
# Parse SuccessResults to enumerate impacted mailboxes
# ==========================
function Get-PurviewImpactedRecipients {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$SearchName,

        [Parameter()]
        [int]$MinItems = 1
    )

    try {
        $search = Get-ComplianceSearch -Identity $SearchName -ErrorAction Stop

        if ($search.Items -le 0) {
            Write-Host "Search '$SearchName' has 0 items, skipping impact enumeration." -ForegroundColor Yellow
            return @()
        }

        # Collapse SuccessResults into one big string so we can regex all occurrences
        $text = ($search.SuccessResults | Out-String).Trim()

        if ([string]::IsNullOrWhiteSpace($text)) {
            Write-Host "Search '$SearchName' has Items=$($search.Items) but SuccessResults is empty or not populated." -ForegroundColor Yellow
            return @()
        }

        # Regex to match *all* "Location: ..., Item count: ..., Total size: ..." chunks
        $pattern = 'Location:\s*(?<Mailbox>[^,]+),\s*Item count:\s*(?<Items>\d+),\s*Total size:\s*(?<Size>\d+)'

        $_matches = [regex]::Matches($text, $pattern)

        if ($_matches.Count -eq 0) {
            Write-Host "SuccessResults is present, but no entries matched the expected pattern." -ForegroundColor Yellow
            return @()
        }

        $mailboxObjects = @()

        foreach ($m in $_matches) {
            $mbx   = $m.Groups['Mailbox'].Value.Trim()
            $items = [int]$m.Groups['Items'].Value
            $size  = [long]$m.Groups['Size'].Value

            if ($items -ge $MinItems) {
                $mailboxObjects += [pscustomobject]@{
                    Mailbox   = $mbx
                    Items     = $items
                    SizeBytes = $size
                }
            }
        }

        if (-not $mailboxObjects -or $mailboxObjects.Count -eq 0) {
            Write-Host "SuccessResults parsed, but no mailboxes had >= $MinItems items." -ForegroundColor Yellow
            return @()
        }

        # --- Summary statistics ---
        $totalItems   = ($mailboxObjects | Measure-Object Items -Sum).Sum
        $totalSize    = ($mailboxObjects | Measure-Object SizeBytes -Sum).Sum
        $mailboxCount = $mailboxObjects.Count

        $largestMailbox = $mailboxObjects | Sort-Object Items     -Descending | Select-Object -First 1
        $largestBySize  = $mailboxObjects | Sort-Object SizeBytes -Descending | Select-Object -First 1

        $summary = [pscustomobject]@{
            TotalItems           = $totalItems
            TotalSizeBytes       = $totalSize
            MailboxCount         = $mailboxCount
            LargestMailbox       = $largestMailbox.Mailbox
            LargestItemCount     = $largestMailbox.Items
            LargestBySizeMailbox = $largestBySize.Mailbox
            LargestBySizeBytes   = $largestBySize.SizeBytes
        }

        return [pscustomobject]@{
            Summary    = $summary
            PerMailbox = $mailboxObjects | Sort-Object Mailbox
        }
    }
    catch {
        Write-Host "Failed to get impacted recipients for '$SearchName': $_" -ForegroundColor Red
        return @()
    }
}

# ==========================
# Pretty table output for impacted mailboxes
# ==========================
function Show-PurviewImpactTable {
    param(
        [Parameter(Mandatory)]
        $ImpactResults
    )

    if (-not $ImpactResults -or -not $ImpactResults.PerMailbox) {
        Write-Host "No impact data available." -ForegroundColor Yellow
        return
    }

    $rows = $ImpactResults.PerMailbox

    # Determine column widths
    $colMailbox = ([string]::Concat(
        "Mailbox",
        (" " * [Math]::Max(0, ($rows.Mailbox | Measure-Object -Maximum Length).Maximum - 7))
    ))
    $colItems   = ([string]::Concat(
        "Items",
        (" " * [Math]::Max(0, ($rows.Items | ForEach-Object { $_.ToString().Length } | Measure-Object -Maximum).Maximum - 5))
    ))
    $colSize    = ([string]::Concat(
        "SizeBytes",
        (" " * [Math]::Max(0, ($rows.SizeBytes | ForEach-Object { $_.ToString().Length } | Measure-Object -Maximum).Maximum - 9))
    ))

    $widthMailbox = $colMailbox.Length
    $widthItems   = $colItems.Length
    $widthSize    = $colSize.Length

    $border = "+" + ("-" * ($widthMailbox+2)) + "+" + ("-" * ($widthItems+2)) + "+" + ("-" * ($widthSize+2)) + "+"

    Write-Host ""
    Write-Host $border
    Write-Host ("| {0} | {1} | {2} |" -f $colMailbox, $colItems, $colSize)
    Write-Host $border

    foreach ($r in $rows) {
        $mailbox = $r.Mailbox.PadRight($widthMailbox)
        $items   = $r.Items.ToString().PadRight($widthItems)
        $size    = $r.SizeBytes.ToString().PadRight($widthSize)

        # Colour code high hit count
        if ($r.Items -ge 10) {
            Write-Host ("| {0} | {1} | {2} |" -f $mailbox, $items, $size) -ForegroundColor Red
        }
        elseif ($r.Items -ge 5) {
            Write-Host ("| {0} | {1} | {2} |" -f $mailbox, $items, $size) -ForegroundColor Yellow
        }
        else {
            Write-Host ("| {0} | {1} | {2} |" -f $mailbox, $items, $size)
        }
    }

    Write-Host $border
    Write-Host ""
}

# ==========================
# Sanity check before submitting purge
# ==========================
function Confirm-PurgeReadiness {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$SearchName
    )

    $search = Get-ComplianceSearch -Identity $SearchName -ErrorAction Stop
    if (-not ($search.Status -in 'Completed','PartiallySucceeded')) {
        Write-Host "Search is not in a terminal state: $($search.Status)" -ForegroundColor Yellow
        return $false
    }

    $items = 0
    try { if ($search.Items) { $items = [int]$search.Items } } catch {}

    if ($items -le 0) {
        Write-Host "Search '$SearchName' has zero items. Nothing to purge." -ForegroundColor Yellow
        return $false
    }

    return $true
}

# ==========================
# Build unique Phish search name (prefix + ticket + sender + timestamp)
# ==========================
function New-PhishSearchName {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Prefix,

        [Parameter(Mandatory)]
        [string]$_Sender,

        [Parameter(Mandatory)]
        [string]$Ticket
    )

    # Normalise sender for use in a Purview search name
    $sanitisedSender = $_Sender.ToLower() -replace '[^a-z0-9]', ''

    # Timestamp in a filename/search-safe format
    $timestamp = (Get-Date).ToUniversalTime().ToString('yyyyMMddTHHmmssZ')

    # Construct
    $name = "${Prefix}_${Ticket}_${sanitisedSender}_${timestamp}"

    # Purview search name limit is 64 chars
    if ($name.Length -gt 64) {
        $name = $name.Substring(0, 64)
    }

    return $name
}

# ==========================
# Lookup search + purge action status
# ==========================
function Get-PurviewPurgeStatus {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$SearchName
    )

    $result = [pscustomobject]@{
        Search      = $null
        PurgeAction = $null
    }

    try {
        $search = Get-ComplianceSearch -Identity $SearchName -ErrorAction Stop
    }
    catch {
        Write-Host "Could not find compliance search '$SearchName': $_" -ForegroundColor Red
        return $null
    }

    $result.Search = $search

    # Try the conventional "<SearchName>_Purge" first
    $purgeName   = "${SearchName}_Purge"
    $purgeAction = Get-ComplianceSearchAction -Identity $purgeName -ErrorAction SilentlyContinue

    if (-not $purgeAction) {
        # Fallback: scan for any purge action tied to this search
        $purgeAction = Get-ComplianceSearchAction -ErrorAction SilentlyContinue |
                       Where-Object { $_.SearchName -eq $SearchName -and $_.Action -eq 'Purge' } |
                       Sort-Object CreatedTime -Descending |
                       Select-Object -First 1
    }

    if (-not $purgeAction) {
        Write-Host "No purge action found for search '$SearchName'." -ForegroundColor Yellow
    }

    $result.PurgeAction = $purgeAction
    return $result
}

# ==========================
# Helper function to grab KeyQL of existing Purview Compliance Search defined by user
# ==========================
function Get-PredefinedPurviewSearch {
    [CmdletBinding()]
    param()

    Write-Host ""
    Write-Host "EXPERIMENTAL FEATURE" -ForegroundColor Yellow
    Write-Host "This will reuse an existing Purview Compliance Search (pre-defined) and copy its ContentMatchQuery." -ForegroundColor Yellow
    Write-Host "Use with caution and validate the query before purging." -ForegroundColor Yellow
    Write-Host ""

    $existingName = Read-Host "Enter the EXACT existing Compliance Search name to reuse"
    if ([string]::IsNullOrWhiteSpace($existingName)) {
        Write-Host "No search name entered. Cancelling experimental mode." -ForegroundColor Yellow
        return $null
    }

    try {
        $s = Get-ComplianceSearch -Identity $existingName -ErrorAction Stop
    } catch {
        Write-Host "Could not find Compliance Search '$existingName': $_" -ForegroundColor Red
        return $null
    }

    if ([string]::IsNullOrWhiteSpace($s.ContentMatchQuery)) {
        Write-Host "Search '$existingName' does not have a ContentMatchQuery to reuse." -ForegroundColor Yellow
        return $null
    }

    return [pscustomobject]@{
        SourceSearchName   = $s.Name
        ContentMatchQuery  = $s.ContentMatchQuery
        ExchangeLocations  = @("All")
    }
}

# ==========================
# Main Purview purge workflow
# ==========================
function Invoke-PurviewPurgeWorkflow {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Username,

        [Parameter()]
        [string]$OrgIdentifier,

        [Parameter(Mandatory)]
        [psobject]$Config,

        [ValidateSet('SoftDelete','HardDelete')]
        [string]$PurgeType = 'SoftDelete',

        [Parameter(Mandatory = $false)]
        [bool]$PurgeLookup = $false
    )

    # 1) Connect to IPPS
    try {
        if ($OrgIdentifier) {
            Connect-IPPS -Username $Username -Organization $OrgIdentifier
        } else {
            Connect-IPPS -Username $Username
        }
    } catch {
        Write-Log -Severity "ERROR" -Message "Failed to connect to IPPSSession for user '$Username'. Error details: $_" -Redact $true
        return
    }

    # Permissions sanity check
    $hasPurgeParam = ($null -ne (Get-Command New-ComplianceSearchAction -ErrorAction SilentlyContinue)) -and
                     ((Get-Command New-ComplianceSearchAction).Parameters.ContainsKey('Purge'))
    if (-not $hasPurgeParam) {
        Write-Log -Severity "WARN" -Message "New-ComplianceSearchAction Purge not available. Likely permissions/feature issue."
        Write-Host "WARNING: New-ComplianceSearchAction Purge not available. Exiting...." -ForegroundColor Red
        return
    }

    # 2.1) Check to see if user wants to lookup a previous purge
    if ($PurgeLookup) {
        try {
            $searchName = Read-Host "Enter the Purview search name to look up (e.g. PhishSearch_<sender>_yyyyMMddTHHmmssZ)"
            if ([string]::IsNullOrWhiteSpace($searchName)) {
                Write-Host "No search name entered. Aborting lookup." -ForegroundColor Yellow
                return
            }

            $status = Get-PurviewPurgeStatus -SearchName $searchName
            if (-not $status) {
                return
            }

            Write-Host "`n=== Compliance Search ===" -ForegroundColor Cyan
            $status.Search | Select-Object Name, Status, Items, Size, JobEndTime | Format-List

            if ($status.PurgeAction) {
                Write-Host "`n=== Purge Action ===" -ForegroundColor Cyan
                $status.PurgeAction |
                    Select-Object Name, SearchName, Action, PurgeType, Status, CreatedTime, LastModifiedTime |
                    Format-List

                if ($status.PurgeAction.Status -eq 'Completed') {
                    Write-Host "Purge has completed successfully." -ForegroundColor Green
                }
                elseif ($status.PurgeAction.Status -eq 'Failed') {
                    Write-Host "Purge finished with a failure status." -ForegroundColor Red
                }
                else {
                    Write-Host "Purge is not yet in a terminal state (Completed/Failed)." -ForegroundColor Yellow
                }
            }
            else {
                Write-Host "No purge action has been created (or found) for this search." -ForegroundColor Yellow
            }
        }
        catch {
            Write-Host "Error while looking up purge status: $_" -ForegroundColor Red
            Write-Log -Severity "ERROR" -Message "Error while looking up purge status: $_" -Redact $true
        }
        return
    }

    # 2.2) Prompt for FS Ticket number
    $_FSTicket = Read-Host -Prompt "Enter Fresh Service Ticket Number (required)"
    if ([string]::IsNullOrWhiteSpace($_FSTicket)) {
        Write-Host "Ticket Number is required." -ForegroundColor Yellow
        return
    }

    # 2.3) Prompt for search parameters
    $_sender = Read-Host -Prompt "Enter Sender Email Address (optional, press ENTER to skip)"

    $useExperimentalPredefined = $false
    $predef = $null

    if ([string]::IsNullOrWhiteSpace($_sender)) {
        Write-Host ""
        Write-Host "Sender was left blank." -ForegroundColor Yellow
        $ans = Read-Host "Would you like to use a pre-defined Purview Compliance Search instead? (EXPERIMENTAL) (Y/N)"
        if ($ans.StartsWith('Y','CurrentCultureIgnoreCase')) {
            $useExperimentalPredefined = $true
        }
    }

    if (-not $useExperimentalPredefined) {
        $subject    = Read-Host -Prompt "Enter Subject (optional, press ENTER to skip)"
        $recipsRaw  = Read-Host -Prompt "Enter Recipients separated by commas (optional, press ENTER to skip)"
        $hoursRaw   = Read-Host -Prompt "Search within last X hours (optional). If set, date range prompts will be skipped. Enter a number or press ENTER"

        [Nullable[datetime]]$startDate = $null
        [Nullable[datetime]]$endDate   = $null

        if ([string]::IsNullOrWhiteSpace($hoursRaw)) {
            $fromRaw = Read-Host -Prompt "Enter Start Date/Time (e.g. 2025-10-28 09:00), or press ENTER to skip"
            $toRaw   = Read-Host -Prompt "Enter End Date/Time (e.g. 2025-10-29 17:00), or press ENTER to skip"
            if (-not [string]::IsNullOrWhiteSpace($fromRaw)) {
                if (-not [datetime]::TryParse($fromRaw, [ref]$startDate)) {
                    Write-Host "Could not parse Start Date. Please use a valid date/time." -ForegroundColor Yellow
                    return
                }
            }
            if (-not [string]::IsNullOrWhiteSpace($toRaw)) {
                if (-not [datetime]::TryParse($toRaw, [ref]$endDate)) {
                    Write-Host "Could not parse End Date. Please use a valid date/time." -ForegroundColor Yellow
                    return
                }
            }
            if ($startDate -and $endDate -and $startDate -gt $endDate) {
                Write-Host "Start Date cannot be after End Date." -ForegroundColor Yellow
                return
            }
        } else {
            [int]$hours = 0
            if (-not [int]::TryParse($hoursRaw, [ref]$hours)) {
                Write-Host "Invalid hours entry. Please provide a whole number." -ForegroundColor Yellow
                return
            }
            $endDate   = Get-Date
            $startDate = (Get-Date).AddHours(-$hours)
        }

        $recipients = @()
        if (-not [string]::IsNullOrWhiteSpace($recipsRaw)) {
            $recipients = $recipsRaw.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }
        }
    }

    # 3) Build KQL
    try {
        if ($useExperimentalPredefined) {
            $predef = Get-PredefinedPurviewSearch
            if (-not $predef) { return }

            $kql = $predef.ContentMatchQuery
        }
        else {
            $kql = New-PurviewKqlQuery -_Sender $_sender -Subject $subject -Recipients $recipients -StartDate $startDate -EndDate $endDate
        }
    } catch {
        Write-Host "Failed to build/select KQL: $_" -ForegroundColor Red
        return
    }

    Write-Host "====================================" -ForegroundColor Cyan
    Write-Host "Purview Search Query (KQL):" -ForegroundColor White
    Write-Host $kql -ForegroundColor Yellow
    Write-Host "====================================" -ForegroundColor Cyan

    # 4) Create/Start search
    $senderForName = if ([string]::IsNullOrWhiteSpace($_sender)) { "NoSender" } else { $_sender }
    $searchName = New-PhishSearchName -Prefix "PhishSearch" -_Sender $senderForName -Ticket $_FSTicket
    
    try {
        Start-PurviewSearch -SearchName $searchName -Kql $kql -ExchangeLocations @("All")
    } catch {
        Write-Log -Severity "ERROR" -Message "Failed to create/start search '$searchName': $_"
        Write-Host "Error creating/starting search." -ForegroundColor Red
        return
    }

    # 5) Wait for completion
    $search = Wait-PurviewSearch -SearchName $searchName -TimeoutSeconds 1200 -PollSeconds 10
    if (-not ($search.Status -in 'Completed','PartiallySucceeded')) {
        Write-Host "Search did not reach a terminal success state: $($search.Status)" -ForegroundColor Yellow
        Write-Host "Please re-try later." -ForegroundColor Yellow
        return
    }

    # 6) Validate results
    $itemCount = 0
    try { if ($search.Items) { $itemCount = [int]$search.Items } } catch {}
    if ($itemCount -le 0) {
        Write-Log -Severity "WARN" -Message "Search '$searchName' returned 0 items. Nothing to purge."
        Write-Host "No results found for your criteria." -ForegroundColor Yellow
        return
    }

    Write-Host "The search found $itemCount item(s)." -ForegroundColor Green

    # 7) Summarise recipients/mailboxes impacted
    $impact = Get-PurviewImpactedRecipients -SearchName $searchName

    if ($impact -and $impact.PerMailbox -and $impact.PerMailbox.Count -gt 0) {
        Write-Host "`nSummary:" -ForegroundColor Cyan
        $impact.Summary | Format-List

        Write-Host "`nPer-Mailbox Breakdown:" -ForegroundColor Cyan
        Show-PurviewImpactTable -ImpactResults $impact
    } else {
        Write-Host "Could not derive mailbox impact from SuccessResults. Proceed with caution." -ForegroundColor Yellow
    }

    # 8) Confirm purge readiness
    if (-not (Confirm-PurgeReadiness -SearchName $searchName)) {
        Write-Host "Not ready for purge." -ForegroundColor Yellow
        return
    }

    Write-Host ""
    Write-Host "Select purge type:" -ForegroundColor Cyan
    Write-Host "1) SoftDelete (Recoverable)" -ForegroundColor Yellow
    Write-Host "2) HardDelete (Permanent)"  -ForegroundColor Red
    $choice = Read-Host "Enter 1 or 2 (default: $PurgeType)"

    switch ($choice) {
        '1' { $PurgeType = 'SoftDelete' }
        '2' { $PurgeType = 'HardDelete' }
        '' { }
        default { 
            Write-Host "Invalid selection. Keeping default: $PurgeType" -ForegroundColor Yellow
        }
    }

    Write-Host "Purge type will be: $PurgeType" -ForegroundColor Cyan
    Write-Host "Purge Search name will be: $searchName" -ForegroundColor Cyan
    $confirm = Read-Host "Proceed with purge of $itemCount item(s)? (Y/N)"
    if (-not $confirm.StartsWith('Y','CurrentCultureIgnoreCase')) {
        Write-Log -Severity "INFO" -Message "Purge aborted by user."
        Write-Host "Purge aborted." -ForegroundColor Yellow
        return
    }

    # 9) Start purge
    try {
        $purge = New-ComplianceSearchAction -SearchName $searchName -Purge -PurgeType $PurgeType -ErrorAction Stop
        Write-Log -Severity "INFO" -Message "Purge action '$($purge.Name)' submitted." -Redact $true
        Write-Host "Purge action '$($purge.Name)' submitted." -ForegroundColor Green
    } catch {
        if ($_ -match 'not supported|disabled|use ediscovery premium|no longer supported') {
            Write-Host "Tenant appears to have 'Search and purge' disabled or restricted. Consider eDiscovery (Premium) workflows." -ForegroundColor Yellow
        }
        Write-Log -Severity "ERROR" -Message "Purge submission failed: $_" -Redact $true
        Write-Host "Purge submission failed." -ForegroundColor Red
        return
    }

    if ($null -eq $purge) {
        Write-Host "Purge not submitted. Skipping status wait." -ForegroundColor Yellow
        return
    }

    # 10) Wait for purge completion (bounded)
    $timeout = 600
    $stopwatch = [Diagnostics.Stopwatch]::StartNew()
    do {
        $action = Get-ComplianceSearchAction -Identity $purge.Name -ErrorAction SilentlyContinue
        if ($action -is [System.Array]) {
            $action = $action | Where-Object { $_.Name -eq $purge.Name -and $_.Action -eq 'Purge' } | Select-Object -First 1
        }
        $status = if ($action) { $action.Status } else { 'Unknown' }
        Write-Host ("[{0:HH:mm:ss}] purge status: {1}" -f (Get-Date), $status)

        if ($status -in 'Completed','Failed') {
            break
        }

        if ($stopwatch.Elapsed.TotalSeconds -ge $timeout) {
            Write-Log -Severity "INFO" -Message "Timeout reached while waiting for purge completion."
            Write-Host ("Timeout ({0}s) reached. Purge may continue in the background." -f [int]$stopwatch.Elapsed.TotalSeconds) -ForegroundColor Yellow
            Write-Host ("You can check the status of the purge by running option 6 in the menu & typing in this search name: $searchName") -ForegroundColor Yellow
            break
        }
        Start-Sleep -Seconds 10
    } while ($true)
    $stopwatch.Stop()

    $final = Get-ComplianceSearchAction -Identity $purge.Name -ErrorAction SilentlyContinue
    if ($final -is [System.Array]) {
        $final = $final | Where-Object { $_.Name -eq $purge.Name -and $_.Action -eq 'Purge' } | Select-Object -First 1
    }

    if ($final) {
        Write-Host "Final Purge Status: $($final.Status)" -ForegroundColor Cyan
        $final | Select-Object Name, SearchName, Action, PurgeType, Status, CreatedTime
        if ($final.Status -eq 'Completed') {
            Write-Host "Purge completed successfully." -ForegroundColor Green
        } elseif ($final.Status -eq 'Failed') {
            Write-Host "Purge finished with a failure status." -ForegroundColor Red
        } else {
            Write-Host "Purge status is not terminal yet, check again later." -ForegroundColor Yellow
        }
    } else {
            Write-Host "Could not retrieve final purge status." -ForegroundColor Yellow
    }
}

# PURGING FUNCTIONS END

# ==========================
# Return the list of mailbox rules
# ==========================
function Get-StoredMailboxRules {
    return $script:MailboxRulesList
}

# ==========================
# Return the last mailbox that was queried
# ==========================
function Get-LastMailboxQueried {
    return $script:LastMailboxQueried
}

# ==========================
# Reset the mailbox state
# ==========================
function Reset-ScriptValues {
    $script:MailboxRulesList = @()
    $script:LastMailboxQueried = $null
}

Export-ModuleMember -Function Test-EOMModule, Test-EOMMinimum, Install-EOMModule, Connect-EOM, Connect-IPPS, Disconnect-EOMSafe, Get-MailboxRules, Get-MailboxAutoReply, Get-InboxRuleHistory, Remove-InboxRuleByID, Invoke-PurviewPurgeWorkflow, Get-StoredMailboxRules, Get-LastMailboxQueried, Reset-ScriptValues, Get-PurviewImpactedRecipients, Show-PurviewImpactTable, Get-PurviewPurgeStatus