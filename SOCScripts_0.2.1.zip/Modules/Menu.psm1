###########################################
# Written by Robert Krolikowski           #
###########################################

# ==========================
# Default Configuration
# ==========================
$script:EOMModule          = $null
$script:IsEOMInstalled     = $false
$script:IsEOMConnected     = $false
$script:ConnectedUser      = $null
$script:EomVersion         = "N/A"
$script:MinimumEomVersion  = "N/A"
$script:HasRules           = $false
$script:TenancyIdentifier  = $null

$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
Import-Module "$PSScriptRoot\Tenancies.psm1" -Force

# ==========================
# Test if a string is a valid mailbox email address
# ==========================
function Test-MailboxInput {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$InputMailbox
    )
    try {
        [void][System.Net.Mail.MailAddress]::new($InputMailbox)
        return $true
    }
    catch {
        return $false
    }
}

# ==========================
# Prompt for input and validate using a provided scriptblock
# ==========================
function Read-ValidatedInput {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [scriptblock]$ValidateScript, 
        [Parameter(Mandatory)]
        [string]$Prompt,
        [string]$InvalidMessage = "Invalid input. Please try again."
    )
    do {
        $rawInput = Read-Host $Prompt
        $inputVal = $rawInput.Trim()

        $isValid  = & $ValidateScript $inputVal

        if (-not $isValid) {
            Write-Host $InvalidMessage -ForegroundColor Red
        }
    } until ($isValid)
    return $inputVal
}

# ==========================
# Build menu items based on connection and rules state
# ==========================
function Get-MenuItems {
    [CmdletBinding()]
    param()
    
    $menuItems = @()
    
    # Not Connected
    if (-not $script:IsEOMConnected) {
        $menuItems += [PSCustomObject]@{
            Option      = '1'
            Description = "Connect to EOM"
            Action      = { Connect-ToEOM }
        }
        $menuItems += [PSCustomObject]@{
            Option      = '2'
            Description = "Exit"
            Action      = { Exit-Script }
        }
        $menuItems += [PSCustomObject]@{
            Option      = '3'
            Description = "Check Configuration Options"
            Action      = { Get-ConfigurationOptions }
        }
    }
    else {
        # Connected
        $menuItems += [PSCustomObject]@{
            Option      = '1'
            Description = "Get All Mailbox Rules"
            Action      = { Get-MailboxRulesInteractive }
        }
        $menuItems += [PSCustomObject]@{
            Option      = '2'
            Description = "Get Specific Mailbox Rule (WIP - Wildcard support coming in the future)"
            Action      = { Get-MailboxSpecificRuleInteractive }
        }
        $menuItems += [PSCustomObject]@{
            Option      = '3'
            Description = "Get Mailbox Auto Reply Configuration"
            Action      = { Get-MailboxAutoReplyConfig }
        }
        $menuItems += [PSCustomObject]@{
            Option      = '4'
            Description = "Search Audit Log for mailbox activity"
            Action      = { Search-MailboxAuditLog }
        }
        # Mailbox has rules
        if ($script:HasRules) {
            $menuItems += [PSCustomObject]@{
                Option      = '5'
                Description = "Search Audit Log for a specific rule activity"
                Action      = { Search-RuleAuditLog }
            }
            $menuItems += [PSCustomObject]@{
                Option      = '6'
                Description = "Remove a rule from mailbox"
                Action      = { Remove-RuleInteractive }
            }
            $menuItems += [PSCustomObject]@{
                Option      = '7'
                Description = "Disconnect from EOM"
                Action      = { Disconnect-FromEOM }
            }
            $menuItems += [PSCustomObject]@{
                Option      = '8'
                Description = "Exit"
                Action      = { Exit-Script }
            }
            $menuItems += [PSCustomObject]@{
                Option      = '9'
                Description = "Check Configuration Options"
                Action      = { Get-ConfigurationOptions }
            }
        }
        else { # No rules
            $menuItems += [PSCustomObject]@{
                Option      = '5'
                Description = "Purge Emails (Requires IPPS - May trigger a new Login Window Prompt)"
                Action      = { Remove-PurgeEmails }
            }
            $menuItems += [PSCustomObject]@{
                Option      = '6'
                Description = "Check Status of Purge (Requires IPPS - May trigger a new Login Window Prompt)"
                Action      = { Get-Purge }
            }
            #$menuItems += [PSCustomObject]@{
            #    Option      = '6'
            #    Description = "Start Investigation"
            #    Action      = { Start-Investigation }
            #}
            $menuItems += [PSCustomObject]@{
                Option      = '7'
                Description = "Disconnect from EOM"
                Action      = { Disconnect-FromEOM }
            }
            $menuItems += [PSCustomObject]@{
                Option      = '8'
                Description = "Exit"
                Action      = { Exit-Script }
            }
            $menuItems += [PSCustomObject]@{
                Option      = '9'
                Description = "Check Configuration Options"
                Action      = { Get-ConfigurationOptions }
            }
        }
    }
    return $menuItems
}

# ==========================
# Display the main menu with current status
# ==========================
function Show-Menu {
    [CmdletBinding()]
    param()
    
    Write-Host "===================================" -ForegroundColor White
    Write-Host "Handy Scripts for SOC - By Robert" -ForegroundColor Cyan
    
    if ($script:IsEOMInstalled) {
        Write-Host "EOM Module Detected: True (Version: $($script:EomVersion) Minimum Required: $($script:MinimumEomVersion)" -ForegroundColor Green
    }
    else {
        Write-Host "EOM Module Detected: False" -ForegroundColor Red
    }
    
    if ($script:IsEOMConnected) {
        Write-Host "Currently Connected to: $($script:ConnectedUser)" -ForegroundColor Green
        
        # If connected user is an email address, attempt to lookup tenancy. To-Do: Move this into a function, as it's being copied in Connect-ToEOM
        if ($script:ConnectedUser -match '@') {
            $userDomain = $script:ConnectedUser -replace '^[^@]+@', ''
            $tenantInfo = $TenantLookup | Where-Object { $_.Domain -eq $userDomain }
            if ($tenantInfo) {
                Write-Log -Severity "INFO" -Message "Tenancy Detected: $($tenantInfo.Tenancy)"
                Write-Host "Tenancy Detected: $($tenantInfo.Tenancy)" -ForegroundColor Cyan
            }
            else {
                Write-Host "Tenancy Detected: Unknown" -ForegroundColor Yellow
            }
        }
        
        if ($script:HasRules) {
            Write-Host "Currently querying mailbox: $(Get-LastMailboxQueried)" -ForegroundColor Green
        }
    }
    else {
        Write-Host "EOM Currently Disconnected" -ForegroundColor Yellow
    }
    
    Write-Host "===================================" -ForegroundColor White


    # Display menu items.
    $menuItems = Get-MenuItems
    foreach ($item in $menuItems) {
        # Color exit differently
        if ($item.Description -match "Exit") {
            Write-Host "$($item.Option). $($item.Description)" -ForegroundColor Red
        }
        else {
            Write-Host "$($item.Option). $($item.Description)" -ForegroundColor White
        }
    }
    Write-Host "===================================" -ForegroundColor White
}


# ==========================
# Establish connection to Exchange Online Management, installing the module as required
# ==========================
function Connect-ToEOM {
    [CmdletBinding()]
    param()
    try {
        # Ensure minimum EOM version
        $ok = Test-EOMMinimum -MinimumVersion '3.9.0'
        if (-not $ok) {
            Write-Log -Severity "ERROR" -Message "ExchangeOnlineManagement 3.9.0+ is required."
            return
        }

        $check = Test-EOMModule -MinimumVersion '3.9.0'
        $script:IsEOMInstalled   = $check.Installed
        $script:EOMMeetsMinimum  = $check.MeetsMinimum
        $script:EomVersion       = $check.InstalledVersion
        $script:MinimumEomVersion= $check.MinimumVersion

        $adminUsername = Read-ValidatedInput -Prompt "Enter your admin username (UPN)" `
                                               -ValidateScript { param($inp) return ($inp -match '.+@.+\..+') } `
                                               -InvalidMessage "Please enter a valid UPN format."
        
        # Setting this to Waterstons for now. However, this may be an array if other tenancies require GDAP as well. Should move this to TEnancies.psm1 in the future.                                       
        $gdapAllowedDomain = 'waterstons.com'
        
        if ($adminUsername -match "@$([regex]::Escape($gdapAllowedDomain))$") {
            # Only now do we ask about GDAP
            $GDAPTenant = Read-ValidatedInput -Prompt "GDAP Tenant? (Yes/No or Y/N)" `
                                                    -ValidateScript {
                                                    param($inp)
                                                    $inp = $inp.Trim().ToLower()
                                                    return ($inp -eq "yes" -or $inp -eq "y" -or $inp -eq "no" -or $inp -eq "n")
                                                } `
                                                -InvalidMessage "Invalid input. Please answer with Yes or No."

            $GDAPTenantBool = ($GDAPTenant.Trim().ToLower() -in @("yes", "y"))
        }
        else {
            # If it's not the right domain, just assume “No”
            $GDAPTenantBool = $false
        }

        if($GDAPTenantBool) {
            # Ask for tenancy identifier
            $tenantIdentifier = Read-ValidatedInput -Prompt "Enter the tenant identifier (e.g. example.onmicrosoft.com)" `
                                          -ValidateScript { 
                                            param($inp) 
                                            return (-not [string]::IsNullOrWhiteSpace($inp)) 
                                        } `
                                          -InvalidMessage "Tenant identifier cannot be empty."

            Write-Host "===================================" -ForegroundColor White
            
            $tenantInfo = $TenantLookup | Where-Object { $_.TenancyIdentifider -eq $tenantIdentifier }
                                        
            if ($tenantInfo) {
                Write-Host "Tenancy Detected: $($tenantInfo.Tenancy)" -ForegroundColor Yellow
                if ($tenantInfo.Note) {
                    Write-Host "Note: $($tenantInfo.Note)" -ForegroundColor Yellow
                }
            }
            else {
                Write-Host "Tenancy Detected: Unknown" -ForegroundColor Yellow
            }
            Write-Host "===================================" -ForegroundColor White

            Connect-EOM -Username $adminUsername -Organization $tenantIdentifier
            Write-Log -Severity "INFO" -Message "Connected successfully as $adminUsername to $tenantIdentifier" -Redact $true
            $script:IsEOMConnected    = $true
            $script:ConnectedUser     = $adminUsername
            $script:TenancyIdentifier = $tenantIdentifier
            # Reset state just in case
            $script:HasRules = $false
            Reset-ScriptValues
        } else {
            Write-Host "===================================" -ForegroundColor White
            # If connected user is an email address, attempt to lookup tenancy & display useful information
            if ($adminUsername -match '@') {
                $userDomain = $adminUsername -replace '^[^@]+@', ''
                $tenantInfo = $TenantLookup | Where-Object { $_.Domain -eq $userDomain }
    
                if ($tenantInfo) {
                    Write-Host "Tenancy Detected: $($tenantInfo.Tenancy)" -ForegroundColor Yellow
                    if ($tenantInfo.Note) {
                        Write-Host "Note: $($tenantInfo.Note)" -ForegroundColor Yellow
                    }
                }
                else {
                    Write-Host "Tenancy Detected: Unknown" -ForegroundColor Yellow
                }
            }
            Write-Host "===================================" -ForegroundColor White

            Connect-EOM -Username $adminUsername
            Write-Log -Severity "INFO" -Message "Connected successfully as $adminUsername." -Redact $true
            $script:IsEOMConnected = $true
            $script:ConnectedUser  = $adminUsername
            # Reset state just in case
            $script:HasRules = $false
            Reset-ScriptValues
        }
    }
    catch {
        # Commenting out temporarily as this error should technically be displayed in Connect-EOM function in EOM.psm1 (Yes, I know the function names shouldn't be the same)
        #Write-Log -Severity "ERROR" -Message "Failed to connect to EOM: $($_.Exception.Message)"
    }
}

# ==========================
# Safely disconnect from Exchange Online Management and reset state
# ==========================
function Disconnect-FromEOM {
    [CmdletBinding()]
    param()
    try {
        Disconnect-EOMSafe

        # Reset states
        $script:IsEOMConnected     = $false
        $script:ConnectedUser      = $null
        $script:HasRules           = $false
        $script:TenancyIdentifier  = $null
        Reset-ScriptValues
    }
    catch {
        # Commenting out temporarily as this error should technically be displayed in Disconnect-EOMSafe function in EOM.psm1
        #Write-Log -Severity "ERROR" -Message "Error disconnecting from EOM: $($_.Exception.Message)"
    }
}

# ==========================
# Exit the script with cleanup
# ==========================
function Exit-Script {
    [CmdletBinding()]
    param()
    Disconnect-FromEOM
    Write-Log -Severity "INFO" -Message "Exiting the script as per user request."
    Write-Host "Thank you for using this tool. Goodbye!" -ForegroundColor Green
    exit
}

# ==========================
# Prompt for mailbox and retrieve all inbox rules
# ==========================
function Get-MailboxRulesInteractive {
    [CmdletBinding()]
    param()
    # Ask for a mailbox address until valid
    $mailboxToCheck = Read-ValidatedInput -Prompt "Enter the mailbox (UPN or SMTP address) you want to check" `
                                            -ValidateScript { param($inp) return (Test-MailboxInput -InputMailbox $inp) } `
                                            -InvalidMessage "Invalid mailbox format. Please try again."

    Get-MailboxRules -Mailbox $mailboxToCheck -Config $Config
    $storedRules = Get-StoredMailboxRules
    $script:HasRules = (@($storedRules)).Count -gt 0
}

# ==========================
# Prompt for mailbox and specific rule name, then attempt to retrieve that rule
# ==========================
function Get-MailboxSpecificRuleInteractive {
    [CmdletBinding()]
    param()
    # Ask for a mailbox address until valid
    $mailboxToCheck = Read-ValidatedInput -Prompt "Enter the mailbox (UPN or SMTP address) you want to check" `
                                            -ValidateScript { param($inp) return (Test-MailboxInput -InputMailbox $inp) } `
                                            -InvalidMessage "Invalid mailbox format. Please try again."

    $RuleName = Read-ValidatedInput -Prompt "Enter the specific rule name to search" `
                                        -ValidateScript { 
                                            param($inp) 
                                            return (-not [string]::IsNullOrWhiteSpace($inp)) 
                                        } `
                                        -InvalidMessage "Rule name cannot be empty."
    Get-MailboxRules -Mailbox $mailboxToCheck -Config $Config -RuleName $RuleName
    $storedRules = Get-StoredMailboxRules
    $script:HasRules = (@($storedRules)).Count -gt 0
}

# ==========================
# Prompt for mailbox and retrieve auto-reply settings
# ==========================
function Get-MailboxAutoReplyConfig {
    [CmdletBinding()]
    param()
    # Ask for a mailbox address until valid
    $mailboxToCheck = Read-ValidatedInput -Prompt "Enter the mailbox (UPN or SMTP address) you want to check" `
                                            -ValidateScript { param($inp) return (Test-MailboxInput -InputMailbox $inp) } `
                                            -InvalidMessage "Invalid mailbox format. Please try again."
    
    Get-MailboxAutoReply -Mailbox $mailboxToCheck -Config $Config
}

# ==========================
# Select a stored rule and show its audit history
# ==========================
function Search-RuleAuditLog {
    [CmdletBinding()]
    param()
    $storedRules = Get-StoredMailboxRules
    if (-not (@($storedRules) -and @($storedRules).Count)) {
        Write-Host "No mailbox rules found. Please run 'Get Mailbox Rules' first." -ForegroundColor Yellow
        Write-Log -Severity "WARN" -Message "No mailbox rules found"
        return
    }

    Write-Host "Select the rule number for detailed information:" -ForegroundColor White
    $storedRules | Format-Table Number, Name, Identity -AutoSize
    $ruleNumber = Read-Host "Enter rule number"
    $selectedRule = $storedRules | Where-Object { $_.Number -eq [int]$ruleNumber }
    if ($selectedRule) {
        $timeRange = 24
        if ($Config.AuditLogTimeRangeHours) {
            $timeRange = [int]$Config.AuditLogTimeRangeHours
        }
        $startDate = (Get-Date).AddHours(-$timeRange)
        $endDate   = Get-Date

        $LastQueriedMailbox = Get-LastMailboxQueried
        Get-InboxRuleHistory -Mailbox $LastQueriedMailbox -RuleName $selectedRule.Name `
                             -StartDate $startDate -EndDate $endDate -Config $Config
    }
    else {
        Write-Host "Invalid rule number selected." -ForegroundColor Yellow
    }
}

# ==========================
# Retrieve all mailbox audit log for rule activity
# ==========================
function Search-MailboxAuditLog {
    [CmdletBinding()]
    param()
    $QueriedMailbox = Get-LastMailboxQueried

    $timeRange = 24
    if ($Config.AuditLogTimeRangeHours) {
        $timeRange = [int]$Config.AuditLogTimeRangeHours
    }
    $startDate = (Get-Date).AddHours(-$timeRange)
    $endDate   = Get-Date

    if (-not $QueriedMailbox) {
        $mailboxToCheck = Read-ValidatedInput -Prompt "Enter the mailbox (UPN or SMTP address) you want to check" `
                                                -ValidateScript { param($inp) return (Test-MailboxInput -InputMailbox $inp) } `
                                                -InvalidMessage "Invalid mailbox format. Please try again."
        Get-InboxRuleHistory -Mailbox $mailboxToCheck -StartDate $startDate -EndDate $endDate -Config $Config -SkipRulename $true
    }
    else {
        Get-InboxRuleHistory -Mailbox $QueriedMailbox -StartDate $startDate -EndDate $endDate -Config $Config -SkipRulename $true
    }
}

# ==========================
# Select a stored rule and remove it
# ==========================
function Remove-RuleInteractive {
    [CmdletBinding()]
    param()
    $storedRules = Get-StoredMailboxRules
    if (-not (@($storedRules) -and @($storedRules).Count)) {
        Write-Host "No mailbox rules found. Please run 'Get Mailbox Rules' first." -ForegroundColor Yellow
        Write-Log -Severity "WARN" -Message "No mailbox rules found"
        return
    }
    Write-Host "Select the rule number for removal:" -ForegroundColor White
    $storedRules | Format-Table Number, Name, Identity -AutoSize
    $ruleNumber = Read-Host "Enter rule number"
    $selectedRule = $storedRules | Where-Object { $_.Number -eq [int]$ruleNumber }
    if ($selectedRule) {
        $LastQueriedMailbox = Get-LastMailboxQueried
        if (-not $LastQueriedMailbox) {
            Write-Log -Severity "ERROR" -Message "Could not determine the last queried mailbox."
        }
        else {
            Remove-InboxRuleByID -Mailbox $LastQueriedMailbox -RuleID $selectedRule.Identity -Config $Config
        }
    }
    else {
        Write-Host "Invalid rule number selected." -ForegroundColor Yellow
    }
}

# ==========================
# Create and monitor a purge search for phishing emails via IPPS (To-Do --- Improve this, this is currently copy-pasta'd from the script we use, I'm sure I can improve this further)
# ==========================
function Remove-PurgeEmails {
    [CmdletBinding()]
    param()

    try {
        if([string]::IsNullOrWhiteSpace($script:TenancyIdentifier)) {
            Invoke-PurviewPurgeWorkflow -Username $script:ConnectedUser -Config $Config
        } else {
            Invoke-PurviewPurgeWorkflow -Username $script:ConnectedUser -OrgIdentifier $script:TenancyIdentifier -Config $Config
        }
    }
    catch {
        Write-Log -Severity "ERROR" -Message "Error in Purview purge workflow: $_"
        Write-Host "Error in Purview purge workflow." -ForegroundColor Red
    }
}

# ==========================
# Lookup the status of any purge
# ==========================
function Get-Purge {
    [CmdletBinding()]
    param()

    try {
        if([string]::IsNullOrWhiteSpace($script:TenancyIdentifier)) {
            Invoke-PurviewPurgeWorkflow -Username $script:ConnectedUser -Config $Config -PurgeLookup:$true
        } else {
            Invoke-PurviewPurgeWorkflow -Username $script:ConnectedUser -OrgIdentifier $script:TenancyIdentifier -Config $Config -PurgeLookup:$true
        }
    }
    catch {
        Write-Log -Severity "ERROR" -Message "Error in Purview purge workflow (lookup mode): $_"
        Write-Host "Error in Purview purge lookup." -ForegroundColor Red
    }
}

function New-CaseHtml {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [psobject]$Case
    )

    $styleTag = @(
        '<style>',
        'body{font-family:"Segoe UI",Arial;margin:20px}',
        'h1{background:#0366d6;color:#fff;padding:10px;border-radius:4px}',
        'table{border-collapse:collapse;width:100%;margin-bottom:25px}',
        'th,td{border:1px solid #ddd;padding:6px}',
        'th{background:#f2f2f2}',
        '</style>'
    ) -join "`n"

    $summary = @(
        [pscustomobject]@{Property='Case Id'; Value=$Case.CaseId},
        [pscustomobject]@{Property='Mailbox'; Value=$Case.Mailbox},
        [pscustomobject]@{Property='Investigator'; Value=$Case.Investigator},
        [pscustomobject]@{Property='Generated On'; Value=$Case.GeneratedOn},
        [pscustomobject]@{Property='Audit Time Range'; Value="$($Case.StartDate) - $($Case.EndDate)"}
    ) | ConvertTo-Html -As Table -Fragment | Out-String

    $rules = $Case.Rules |
             Select-Object Name, Enabled, Priority, ForwardTo, RedirectTo, MoveToFolder |
             ConvertTo-Html -As Table -Fragment | Out-String

    $audit = $Case.InboxRuleAudit |
            Select-Object  Timestamp,
                        Operation,
                        Initiator,
                # Check to see where the rule name is stored
                @{ Name       = 'RuleName'
                Expression = {
                    if     ($_.RuleName   )               { $_.RuleName }
                    elseif ($_.PSObject.Properties['Param_RuleName']) { $_.'Param_RuleName' }
                    elseif ($_.PSObject.Properties['Param_Name'])     { $_.'Param_Name' }
                    else  { '' }
                }
                },
                        ClientIP |
             ConvertTo-Html -As Table -Fragment | Out-String

    $htmlLines = @(
        '<!DOCTYPE html>',
        '<html lang="en">',
        '<head>',
        '<meta charset="utf-8" />',
        "<title>Mailbox Investigation - $($Case.Mailbox)</title>",
        $styleTag,
        '</head>',
        '<body>',
        '<h1>Mailbox Investigation Report</h1>',
        '<h2>Summary</h2>',
        $summary,
        "<h2>Mailbox Rules ($($Case.Rules.Count))</h2>",
        $rules,
        "<h2>Inbox-Rule Audit Events ($($Case.InboxRuleAudit.Count))</h2>",
        $audit,
        '</body>',
        '</html>'
    )

    return ($htmlLines -join "`n")
}

# ==========================
# Helper for Start-Investigation used to export the case
# ==========================
function Export-Case {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [psobject]$Case,

        [Parameter()]
        [String]$OutDir = (Join-Path $scriptDirectory 'Cases')
    )

    # Ensure this folder exists
    if (-not (Test-Path $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }

    $baseName = "$($Case.CaseId)"
    $htmlPath = Join-Path $OutDir "$baseName.html"

    $html = New-CaseHtml -Case $Case
    $html | Out-File $htmlPath -Encoding utf8

    Write-Host "Case exported:`n  - HTML: $htmlPath" -ForegroundColor Green
}

# ==========================
# Start investigation on user account
# ==========================
function Start-Investigation {
    [CmdletBinding()]
    param()

    $timeRange = 24
    if ($Config.AuditLogTimeRangeHours) {
        $timeRange = [int]$Config.AuditLogTimeRangeHours
    }
    $startDate = (Get-Date).AddHours(-$timeRange)
    $endDate   = Get-Date

    $mailboxToCheck = Read-ValidatedInput -Prompt "Enter the mailbox (UPN or SMTP address) you want to check" `
                                            -ValidateScript { param($inp) return (Test-MailboxInput -InputMailbox $inp) } `
                                            -InvalidMessage "Invalid mailbox format. Please try again."

    $case = [pscustomobject]@{
        CaseId             = [guid]::NewGuid()
        Mailbox            = $mailboxToCheck
        Investigator       = $script:ConnectedUser
        GeneratedOn        = Get-Date
        StartDate          = $startDate
        EndDate            = $endDate
        Rules              = @()
        InboxRuleAudit     = @()
        AutoReply          = $null
        Notes              = @()
    }

    # Get all mailbox rules
    Get-MailboxRules -Mailbox $mailboxToCheck -Config $Config -SkipOutput $true
    Write-Host "Finished looking up mailbox rules" -ForegroundColor Green
    $case.rules = Get-StoredMailboxRules

    # Get Inbox Audit logs
    $case.InboxRuleAudit = Get-InboxRuleHistory -Mailbox $mailboxToCheck -StartDate $startDate -EndDate $endDate -Config $Config -SkipRulename $true -SkipOutput $true
    Write-Host "Finished looking up inbox audit logs" -ForegroundColor Green

    $case.AutoReply = Get-MailboxAutoReply -Mailbox $mailboxToCheck -Config $Config -SkipOutput $true
    Write-Host "Finished looking up auto reply configuration" -ForegroundColor Green
    
    $case.Notes += "Total rules    : $($case.Rules.Count)"
    $case.Notes += "Audit log hits : $($case.InboxRuleAudit.Count)"

    Write-Host "Starting case export" -ForegroundColor Green
    Export-Case -Case $case
}

# ==========================
# Display currently loaded configuration options
# ==========================
function Get-ConfigurationOptions {
    [CmdletBinding()]
    param()
    Write-Host "=======Configuration Options=======" -ForegroundColor Yellow
    Write-Host "Debug: $($Config.Debug)" -ForegroundColor White
    Write-Host "Log Filename: $($Config.LogFileName)" -ForegroundColor White
    Write-Host "Log Directory Name: $($Config.LogDirectory)" -ForegroundColor White
    Write-Host "Use Timestamped Logs?: $($Config.UseTimestampedLogs)" -ForegroundColor White
    Write-Host "Maximum Log Files Allowed: $($Config.MaxLogFiles)" -ForegroundColor White
    Write-Host "Maximum Audit Log Timerange Hours to Search for: $($Config.AuditLogTimeRangeHours)" -ForegroundColor White
    Write-Host "Maximum Audit Log Result Size: $($Config.AuditLogResultSize)" -ForegroundColor White
    Write-Host "===================================" -ForegroundColor Yellow
}

# ==========================
# Main Loop: Initialize Exchange Online Mnaagment state and display menu until exit
# ==========================
function Get-Menu {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$ScriptDirectory,
        
        [Parameter(Mandatory)]
        [psobject]$Config
    )

    try {
        $check = Test-EOMModule -MinimumVersion '3.9.0'
        $script:IsEOMInstalled   = $check.Installed
        $script:EOMMeetsMinimum  = $check.MeetsMinimum
        $script:EomVersion       = $check.InstalledVersion
        $script:MinimumEomVersion= $check.MinimumVersion
    } catch {
        Write-Log -Severity "ERROR" -Message "Failed to test EOM module: $_"
        $script:IsEOMInstalled  = $false
        $script:EOMMeetsMinimum = $false
        $script:EomVersion      = $null
    }

    # Main Loop here
    while ($true) {
        Show-Menu
        $menuItems = Get-MenuItems
        $choice = Read-Host "Enter your choice"

        $selected = $menuItems | Where-Object { $_.Option -eq $choice }
        if ($selected) {
            try {
                & $selected.Action
            }
            catch {
                Write-Log -Severity "ERROR" -Message "Error processing menu action: $($_.Exception.Message)"
            }
        }
        else {
            Write-Host "Invalid choice. Please select a valid menu option." -ForegroundColor Yellow
        }
    }
}

Export-ModuleMember -Function Show-Menu, Get-Menu
